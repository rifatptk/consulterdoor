import { AddServiceContainer } from '../../components';
import { PageContainer } from '../../components/shared';

function AddService() {
  return (
    <PageContainer>
      <div>
        <div>
          <AddServiceContainer />
        </div>
      </div>
    </PageContainer>
  );
}

export { AddService };
