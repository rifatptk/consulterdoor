import { VideoRoom } from '../../components';

const VideoChat = () => {
  return <VideoRoom />;
};

export { VideoChat };
