import { SearchTag } from './searchTag';

export {
    SearchTag
};
