import { SearchTag } from './tags';

export {
    SearchTag
};
