import { ConsultantRegister } from './consultantRegister';
export { ConsultantRegister };
