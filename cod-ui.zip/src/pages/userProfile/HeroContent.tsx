const HeroContent = () => {
  return (
    <div className="userprofile-content my-5">
      <h3>Discription About Service</h3>
      <p>
        consectetur adipiscing elit. Viverra magna nunc risus iaculis eleifend
        id facilisi. Consectetur ut at sapien lacinia libero eu. Viverra
        adipiscing curabitur enim maecenas facilisi facilisis lacus euismod
        enim. Lacus quis nec pellentesque dictum feugiat vulputate. Iaculis
        elit, nullam in ve nenatis consequat ultrices hendrerit pulvinar eget.
        Viverra id hac malesuada purus, nunc, ultricies ac integer. Tempus urna,
        Viverra adipiscing curabitur facilisi facilisis lacus euismod enim.
        Lacus quis nec pellentesque dictum feugiat vulputate. Viverra id hac
        malesuada purus, nunc, ultricies ac integer. Tempus urna, Viverra
        adipiscing curabitur facilisi facilisis lacus euismod enim. Lacus quis
        nec pellentesque dictum feugiat vulputate.{' '}
      </p>

      <h3>Tools and Techniques</h3>
      <p>
        consectetur adipiscing elit. Viverra magna nunc risus iaculis eleifend
        id facilisi. Consectetur ut at sapien lacinia libero eu. Viverra
        adipiscing curabitur enim maecenas facilisi facilisis lacus euismod
        enim. Lacus quis nec pellentesque dictum feugiat vulputate. Iaculis
        elit, nullam in ve nenatis consequat ultrices hendrerit pulvinar eget.
        Viverra id hac malesuada purus, nunc, ultricies ac integer. Tempus urna,
        Viverra adipiscing curabitur facilisi facilisis lacus euismod enim.
        Lacus quis nec pellentesque dictum feugiat vulputate. Viverra id hac
        malesuada purus, nunc, ultricies ac integer. Tempus urna, Viverra
        adipiscing curabitur facilisi facilisis lacus euismod enim. Lacus quis
        nec pellentesque dictum feugiat vulputate.
      </p>
    </div>
  );
};

export default HeroContent;
