import { ConsultantEducationRegistration } from './consultantEducation';
import { ConsultantProfileRegistration } from './consultantProfile';

export { ConsultantProfileRegistration, ConsultantEducationRegistration };
