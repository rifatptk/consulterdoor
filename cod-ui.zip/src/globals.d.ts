declare module 'react-logger-lib';
declare module '@chatscope/chat-ui-kit-styles/dist/default/styles.min.css';
